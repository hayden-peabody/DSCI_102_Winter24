OK_FORMAT = True

test = {   'name': 'q2_1_2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> distance_two_features(movie, "monty python and the holy grail", "water", "feel") < .001\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
