OK_FORMAT = True

test = {   'name': 'q3_1_6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> len(my_features) >= 10\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> train_my_features.shape == (314, len(my_features))\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> test_my_features.shape == (56, len(my_features))\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
