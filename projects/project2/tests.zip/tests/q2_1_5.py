OK_FORMAT = True

test = {   'name': 'q2_1_5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(most_common("Genre", close_movies)) == str\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
