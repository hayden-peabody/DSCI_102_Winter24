OK_FORMAT = True

test = {   'name': 'q2_1_4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> close_movies.shape == (5,4)\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
