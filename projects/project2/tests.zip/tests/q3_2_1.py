OK_FORMAT = True

test = {   'name': 'q3_2_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(classify(test_my_features.iloc[0,:], train_my_features, np.array(train_movies["Genre"]), 7)) == str\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
