OK_FORMAT = True

test = {   'name': 'q3_3_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> (proportion_correct <= 1) & (proportion_correct >= 0)\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
