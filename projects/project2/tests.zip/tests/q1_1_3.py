OK_FORMAT = True

test = {   'name': 'q1_1_3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(longest_uncut) == str\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
