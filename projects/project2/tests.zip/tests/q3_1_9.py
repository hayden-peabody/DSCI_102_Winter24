OK_FORMAT = True

test = {   'name': 'q3_1_9',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.isin(my_assigned_genre,["thriller","comedy"])\n'
                                       'array(True)',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
