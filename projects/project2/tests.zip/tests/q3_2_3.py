OK_FORMAT = True

test = {   'name': 'q3_2_3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(classify_feature_row(test_my_features.iloc[0,:])) == str\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
