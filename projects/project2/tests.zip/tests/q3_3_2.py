OK_FORMAT = True

test = {   'name': 'q3_3_2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> test_movie_correctness.shape == (56, 3)\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
