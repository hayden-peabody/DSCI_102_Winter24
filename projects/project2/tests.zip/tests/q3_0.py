OK_FORMAT = True

test = {   'name': 'q3_0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> distance(np.array(train_movies.iloc[0,5:]), np.array(train_movies.iloc[1,5:])) < .1\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
