OK_FORMAT = True

test = {   'name': 'q3_1_8',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> genre_and_distances.shape == (314, 2)\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
