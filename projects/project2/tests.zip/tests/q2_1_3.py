OK_FORMAT = True

test = {   'name': 'q2_1_3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> distance_from_python("clerks.") < .001\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
