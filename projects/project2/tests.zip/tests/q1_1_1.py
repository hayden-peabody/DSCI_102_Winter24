OK_FORMAT = True

test = {   'name': 'q1_1_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(stemmed_message) == str\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
