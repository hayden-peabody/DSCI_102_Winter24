OK_FORMAT = True

test = {   'name': 'q3_1_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.isin(bottom_left, [1,2,3,4,5])\n'
                                       'array(True)',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
