OK_FORMAT = True

test = {   'name': 'q1_2_1',
    'points': 1,
    'suites': [   {   'cases': [  {   'code': '>>> np.isclose(outer_space_r, 0.2829, .01)\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
