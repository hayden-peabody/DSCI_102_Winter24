OK_FORMAT = True

test = {   'name': 'q1_1_2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(most_stem) == str\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
