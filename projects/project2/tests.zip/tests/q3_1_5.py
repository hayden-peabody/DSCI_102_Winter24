OK_FORMAT = True

test = {   'name': 'q3_1_5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.isin(movie_genre_guess, [1,2])\n'
                                       'array(True)',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
