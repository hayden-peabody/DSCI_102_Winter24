OK_FORMAT = True

test = {   'name': 'q2_1_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> one_distance < .001\n'
                                       'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
